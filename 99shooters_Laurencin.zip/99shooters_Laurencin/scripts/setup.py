#création d'un executable

from cx_Freeze import setup, Executable
  
executables = [
        Executable(script = "99shooters.py", base = "Win32GUI" )
]
  
buildOptions = dict( 
        includes = ["tkinter","tkinter.messagebox"],
        include_files = ["musique.gif"]
)
  
setup(
    name = "99shooters",
    version = "1.0",
    description = "Afficher partiellement ou entièrement la chanson 99",
    author = "Laurencin Muriel",
    options = dict(build_exe = buildOptions),
    executables = executables
)
