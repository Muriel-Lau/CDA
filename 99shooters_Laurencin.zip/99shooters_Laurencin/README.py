"""
----- Application pour afficher un couplet, la fin de la chanson et la chanson entière----
----- Créée par M. Laurencin - dernière- version le 24 décembre 2020 ----
----- Développée en Python 38 et tkinter ----

>>> Dans le dossier Applications-99shooters il y a :
** l'executable de l'application et toutes les librairies \
nécessaires à lancer le programme.

** Pour lancer l'application :
Dans le dossier 'Applications-99shooters' lancer l executable '99shooters' 



>>> Dans le dossier scripts il y a :
** le script de l'application '99shooters.py' développée en Python et Tkinter
** l'image 'musique.gif'
** le script 'setup.py' pour créer l'executable de l'application fait avec cx_Freeze


Si vous avez des questions ou que ça ne fonctionne pas,
\ me contacter par email à muriel.laurencin@orange.fr
